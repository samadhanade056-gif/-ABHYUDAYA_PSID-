import { motion } from "framer-motion";
import { 
  Database, 
  Layers, 
  Cog, 
  BarChart3, 
  CheckCircle,
  ArrowRight
} from "lucide-react";

const steps = [
  {
    icon: Database,
    title: "Data Preparation",
    description: "Load and preprocess CIFAR-10 dataset with normalization and augmentation",
    status: "complete",
    details: ["60,000 training images", "10,000 test images", "32x32 RGB pixels"]
  },
  {
    icon: Layers,
    title: "Model Architecture",
    description: "CNN with convolutional, pooling, and fully connected layers",
    status: "complete",
    details: ["Conv2D layers", "MaxPooling", "Dense layers", "Softmax output"]
  },
  {
    icon: Cog,
    title: "Training",
    description: "Optimize model with cross-entropy loss and Adam optimizer",
    status: "complete",
    details: ["Batch size: 64", "Learning rate: 0.001", "Epochs: 50"]
  },
  {
    icon: BarChart3,
    title: "Evaluation",
    description: "Validate on test set and measure classification accuracy",
    status: "complete",
    details: ["Accuracy metrics", "Confusion matrix", "Per-class analysis"]
  },
  {
    icon: CheckCircle,
    title: "Inference",
    description: "Deploy model for real-time image classification",
    status: "active",
    details: ["Real-time prediction", "Confidence scores", "Multi-class output"]
  }
];

const PipelineVisualization = () => {
  return (
    <section className="py-20 px-4">
      <div className="container max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="text-gradient">Training Pipeline</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Understanding the complete deep learning workflow from data preparation to deployment
          </p>
        </motion.div>

        <div className="grid md:grid-cols-5 gap-4">
          {steps.map((step, index) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className={`
                glass rounded-2xl p-5 h-full
                ${step.status === "active" ? "border-primary glow-primary" : ""}
              `}>
                <div className={`
                  w-12 h-12 rounded-xl flex items-center justify-center mb-4
                  ${step.status === "active" 
                    ? "gradient-primary text-primary-foreground" 
                    : "bg-secondary text-muted-foreground"
                  }
                `}>
                  <step.icon className="w-6 h-6" />
                </div>
                
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {step.title}
                </h3>
                
                <p className="text-sm text-muted-foreground mb-4">
                  {step.description}
                </p>
                
                <ul className="space-y-1">
                  {step.details.map((detail) => (
                    <li key={detail} className="text-xs font-mono text-muted-foreground flex items-center gap-2">
                      <span className={`w-1.5 h-1.5 rounded-full ${step.status === "active" ? "bg-primary" : "bg-muted-foreground/50"}`} />
                      {detail}
                    </li>
                  ))}
                </ul>
              </div>
              
              {index < steps.length - 1 && (
                <div className="hidden md:flex absolute top-1/2 -right-3 z-10 text-border">
                  <ArrowRight className="w-6 h-6" />
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PipelineVisualization;