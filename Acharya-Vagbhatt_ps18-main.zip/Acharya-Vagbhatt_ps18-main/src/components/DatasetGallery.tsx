import { motion } from "framer-motion";

const categories = [
  { name: "Airplane", emoji: "✈️", color: "from-sky-500 to-blue-600" },
  { name: "Automobile", emoji: "🚗", color: "from-red-500 to-rose-600" },
  { name: "Bird", emoji: "🐦", color: "from-amber-500 to-yellow-600" },
  { name: "Cat", emoji: "🐱", color: "from-orange-500 to-amber-600" },
  { name: "Deer", emoji: "🦌", color: "from-emerald-500 to-green-600" },
  { name: "Dog", emoji: "🐕", color: "from-violet-500 to-purple-600" },
  { name: "Frog", emoji: "🐸", color: "from-lime-500 to-green-600" },
  { name: "Horse", emoji: "🐎", color: "from-yellow-500 to-orange-600" },
  { name: "Human", emoji: "🧑", color: "from-pink-500 to-fuchsia-600" },
  { name: "Ship", emoji: "🚢", color: "from-cyan-500 to-teal-600" },
  { name: "Truck", emoji: "🚚", color: "from-rose-500 to-pink-600" },
];

const DatasetGallery = () => {
  return (
    <section className="py-20 px-4">
      <div className="container max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="text-gradient">CIFAR-10 Categories</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Our model is trained to recognize these 10 distinct object categories
          </p>
        </motion.div>

        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-11 gap-3">
          {categories.map((category, index) => (
            <motion.div
              key={category.name}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4, delay: index * 0.05 }}
              viewport={{ once: true }}
              whileHover={{ scale: 1.05 }}
              className="cursor-pointer"
            >
              <div className={`
                aspect-square rounded-2xl bg-gradient-to-br ${category.color}
                flex flex-col items-center justify-center p-4
                shadow-card hover:shadow-elevated transition-all duration-300
              `}>
                <span className="text-4xl md:text-5xl mb-3">{category.emoji}</span>
                <span className="text-sm font-medium text-white/90">{category.name}</span>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-12 glass rounded-2xl p-6 grid md:grid-cols-3 gap-6"
        >
          <div className="text-center">
            <p className="text-3xl font-bold text-primary mb-1">60,000</p>
            <p className="text-sm text-muted-foreground">Training Images</p>
          </div>
          <div className="text-center">
            <p className="text-3xl font-bold text-accent mb-1">10,000</p>
            <p className="text-sm text-muted-foreground">Test Images</p>
          </div>
          <div className="text-center">
            <p className="text-3xl font-bold text-success mb-1">32×32</p>
            <p className="text-sm text-muted-foreground">Image Resolution</p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default DatasetGallery;