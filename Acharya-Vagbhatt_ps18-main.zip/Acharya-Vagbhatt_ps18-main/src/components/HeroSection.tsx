import { Brain, Layers, Zap, Database } from "lucide-react";
import { motion } from "framer-motion";

const HeroSection = () => {
  return (
    <section className="relative min-h-[70vh] flex items-center justify-center overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 grid-pattern opacity-30" />
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-background/50 to-background" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full opacity-30" 
           style={{ background: 'var(--gradient-glow)' }} />
      
      <div className="container relative z-10 px-4 py-20">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center max-w-4xl mx-auto"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-primary/30 mb-6">
            <Brain className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary">Deep Learning Powered</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            <span className="text-gradient">Image Classification</span>
            <br />
            <span className="text-foreground">with Neural Networks</span>
          </h1>
          
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10">
            Experience the power of Convolutional Neural Networks (CNNs). Upload any image 
            and watch as our deep learning model classifies it across 10 categories in real-time.
          </p>
          
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <StatCard icon={<Layers className="w-5 h-5" />} label="CNN Architecture" value="Multi-Layer" />
            <StatCard icon={<Database className="w-5 h-5" />} label="Training Set" value="CIFAR-10" />
            <StatCard icon={<Zap className="w-5 h-5" />} label="Inference" value="Real-time" />
          </div>
        </motion.div>
      </div>
    </section>
  );
};

const StatCard = ({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) => (
  <div className="glass rounded-xl px-5 py-3 flex items-center gap-3">
    <div className="text-primary">{icon}</div>
    <div className="text-left">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="text-sm font-semibold text-foreground">{value}</p>
    </div>
  </div>
);

export default HeroSection;