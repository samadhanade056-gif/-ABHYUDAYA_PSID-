import { useState, useCallback } from "react";
import { Upload, Image as ImageIcon, X, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";

interface ImageUploaderProps {
  onImageUpload: (imageData: string) => void;
  isProcessing: boolean;
}

const ImageUploader = ({ onImageUpload, isProcessing }: ImageUploaderProps) => {
  const [dragActive, setDragActive] = useState(false);
  const [previewImage, setPreviewImage] = useState<string | null>(null);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const processFile = useCallback((file: File) => {
    if (!file.type.startsWith("image/")) return;
    
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      setPreviewImage(result);
    };
    reader.readAsDataURL(file);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  }, [processFile]);

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const handleClassify = () => {
    if (previewImage) {
      // Extract base64 data from data URL
      const base64Data = previewImage.split(",")[1];
      onImageUpload(base64Data);
    }
  };

  const clearImage = () => {
    setPreviewImage(null);
  };

  return (
    <div className="w-full max-w-xl mx-auto">
      <AnimatePresence mode="wait">
        {!previewImage ? (
          <motion.div
            key="upload"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.3 }}
          >
            <div
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
              className={`
                relative rounded-2xl border-2 border-dashed transition-all duration-300 cursor-pointer
                ${dragActive 
                  ? "border-primary bg-primary/5 glow-primary" 
                  : "border-border hover:border-primary/50 hover:bg-secondary/30"
                }
              `}
            >
              <input
                type="file"
                accept="image/*"
                onChange={handleFileInput}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
              
              <div className="flex flex-col items-center justify-center py-16 px-8">
                <div className={`
                  p-4 rounded-2xl mb-4 transition-all duration-300
                  ${dragActive ? "bg-primary/20" : "bg-secondary"}
                `}>
                  <Upload className={`w-10 h-10 ${dragActive ? "text-primary" : "text-muted-foreground"}`} />
                </div>
                
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  Drop your image here
                </h3>
                <p className="text-sm text-muted-foreground text-center">
                  or click to browse • Supports JPG, PNG, WEBP
                </p>
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="preview"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.3 }}
            className="relative"
          >
            <div className="rounded-2xl overflow-hidden glass shadow-elevated">
              <div className="relative aspect-square">
                <img
                  src={previewImage}
                  alt="Preview"
                  className="w-full h-full object-cover"
                />
                
                {isProcessing && (
                  <div className="absolute inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center">
                    <div className="text-center">
                      <Loader2 className="w-12 h-12 text-primary animate-spin mx-auto mb-4" />
                      <p className="text-sm font-medium text-foreground">Analyzing image...</p>
                      <p className="text-xs text-muted-foreground">Running CNN inference</p>
                    </div>
                  </div>
                )}
              </div>
              
              <div className="p-4 flex gap-3">
                <Button
                  variant="outline"
                  onClick={clearImage}
                  disabled={isProcessing}
                  className="flex-1"
                >
                  <X className="w-4 h-4 mr-2" />
                  Clear
                </Button>
                <Button
                  onClick={handleClassify}
                  disabled={isProcessing}
                  className="flex-1 gradient-primary text-primary-foreground hover:opacity-90"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Processing
                    </>
                  ) : (
                    <>
                      <ImageIcon className="w-4 h-4 mr-2" />
                      Classify
                    </>
                  )}
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ImageUploader;