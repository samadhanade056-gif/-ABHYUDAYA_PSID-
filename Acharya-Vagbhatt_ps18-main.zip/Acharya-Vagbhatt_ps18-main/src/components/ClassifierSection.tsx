import { useState } from "react";
import { motion } from "framer-motion";
import ImageUploader from "./ImageUploader";
import ClassificationResults from "./ClassificationResults";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface ClassificationResult {
  predicted_class: string;
  confidence: number;
  all_predictions: { class: string; confidence: number }[];
  reasoning: string;
}

const ClassifierSection = () => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<ClassificationResult | null>(null);

  const handleImageUpload = async (imageBase64: string) => {
    setIsProcessing(true);
    setResult(null);

    try {
      const { data, error } = await supabase.functions.invoke("classify-image", {
        body: { imageBase64 },
      });

      if (error) throw error;

      if (data.success) {
        setResult(data.result);
        toast.success("Classification complete!");
      } else {
        throw new Error(data.error || "Classification failed");
      }
    } catch (error) {
      console.error("Classification error:", error);
      toast.error("Failed to classify image. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <section className="py-20 px-4" id="classifier">
      <div className="container max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="text-gradient">Try It Yourself</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Upload an image of an airplane, car, bird, cat, deer, dog, frog, horse, human, ship, or truck
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 items-start">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <ImageUploader 
              onImageUpload={handleImageUpload} 
              isProcessing={isProcessing} 
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            {result ? (
              <ClassificationResults result={result} />
            ) : (
              <div className="glass rounded-2xl p-8 h-full flex items-center justify-center min-h-[400px]">
                <div className="text-center">
                  <div className="w-16 h-16 rounded-full bg-secondary flex items-center justify-center mx-auto mb-4">
                    <span className="text-3xl">🔍</span>
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">
                    Awaiting Image
                  </h3>
                  <p className="text-sm text-muted-foreground max-w-xs">
                    Upload an image to see the CNN classification results with confidence scores
                  </p>
                </div>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default ClassifierSection;