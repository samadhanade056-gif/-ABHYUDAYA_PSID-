import { motion } from "framer-motion";
import { CheckCircle, Brain, Sparkles } from "lucide-react";

interface Prediction {
  class: string;
  confidence: number;
}

interface ClassificationResultsProps {
  result: {
    predicted_class: string;
    confidence: number;
    all_predictions: Prediction[];
    reasoning: string;
  } | null;
}

const classColors: Record<string, string> = {
  airplane: "from-class-1 to-blue-500",
  automobile: "from-class-2 to-orange-500",
  bird: "from-class-3 to-emerald-500",
  cat: "from-class-4 to-violet-500",
  deer: "from-amber-600 to-amber-400",
  dog: "from-rose-500 to-pink-400",
  frog: "from-lime-500 to-green-400",
  horse: "from-indigo-500 to-blue-400",
  human: "from-pink-500 to-fuchsia-400",
  ship: "from-cyan-500 to-teal-400",
  truck: "from-red-500 to-orange-400",
};

const ClassificationResults = ({ result }: ClassificationResultsProps) => {
  if (!result) return null;

  const topPredictions = result.all_predictions.slice(0, 5);
  const colorClass = classColors[result.predicted_class] || "from-primary to-accent";

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full max-w-xl mx-auto"
    >
      <div className="glass rounded-2xl p-6 shadow-elevated">
        {/* Main prediction */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-success/20 text-success mb-4">
            <CheckCircle className="w-4 h-4" />
            <span className="text-sm font-medium">Classification Complete</span>
          </div>
          
          <div className={`inline-block px-6 py-3 rounded-xl bg-gradient-to-r ${colorClass} mb-4`}>
            <h2 className="text-3xl font-bold text-white capitalize">
              {result.predicted_class}
            </h2>
          </div>
          
          <p className="text-lg text-muted-foreground">
            Confidence: <span className="text-foreground font-semibold">{(result.confidence * 100).toFixed(1)}%</span>
          </p>
        </div>

        {/* Confidence bars */}
        <div className="mb-6">
          <h3 className="text-sm font-medium text-muted-foreground mb-4 flex items-center gap-2">
            <Brain className="w-4 h-4" />
            Top 5 Predictions
          </h3>
          
          <div className="space-y-3">
            {topPredictions.map((pred, index) => (
              <motion.div
                key={pred.class}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium capitalize text-foreground">
                    {pred.class}
                  </span>
                  <span className="text-xs font-mono text-muted-foreground">
                    {(pred.confidence * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="h-2 bg-secondary rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${pred.confidence * 100}%` }}
                    transition={{ duration: 0.8, delay: index * 0.1 }}
                    className={`h-full rounded-full bg-gradient-to-r ${
                      index === 0 ? colorClass : "from-muted-foreground/50 to-muted-foreground/30"
                    }`}
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Reasoning */}
        {result.reasoning && (
          <div className="border-t border-border pt-4">
            <h3 className="text-sm font-medium text-muted-foreground mb-2 flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              Model Reasoning
            </h3>
            <p className="text-sm text-foreground/80 leading-relaxed">
              {result.reasoning}
            </p>
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default ClassificationResults;