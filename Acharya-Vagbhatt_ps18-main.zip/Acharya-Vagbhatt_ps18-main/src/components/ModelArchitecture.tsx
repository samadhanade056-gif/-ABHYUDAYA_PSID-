import { motion } from "framer-motion";

const layers = [
  { name: "Input", size: "32×32×3", color: "bg-blue-500" },
  { name: "Conv2D", size: "32×32×32", color: "bg-cyan-500" },
  { name: "MaxPool", size: "16×16×32", color: "bg-teal-500" },
  { name: "Conv2D", size: "16×16×64", color: "bg-emerald-500" },
  { name: "MaxPool", size: "8×8×64", color: "bg-green-500" },
  { name: "Conv2D", size: "8×8×128", color: "bg-lime-500" },
  { name: "Flatten", size: "8192", color: "bg-yellow-500" },
  { name: "Dense", size: "256", color: "bg-amber-500" },
  { name: "Dropout", size: "256", color: "bg-orange-500" },
  { name: "Dense", size: "10", color: "bg-red-500" },
  { name: "Softmax", size: "10", color: "bg-rose-500" },
];

const ModelArchitecture = () => {
  return (
    <section className="py-20 px-4 gradient-hero">
      <div className="container max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="text-gradient-accent">CNN Architecture</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Visual representation of the neural network layers processing your images
          </p>
        </motion.div>

        <div className="glass rounded-2xl p-8 overflow-x-auto">
          <div className="flex items-end justify-center gap-2 min-w-[800px] h-64">
            {layers.map((layer, index) => {
              const height = Math.max(30, 100 - (index * 5));
              
              return (
                <motion.div
                  key={layer.name}
                  initial={{ opacity: 0, height: 0 }}
                  whileInView={{ opacity: 1, height: `${height}%` }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="flex flex-col items-center"
                >
                  <div 
                    className={`w-16 ${layer.color} rounded-t-lg relative group cursor-pointer transition-all hover:opacity-80`}
                    style={{ height: '100%' }}
                  >
                    <div className="absolute -top-16 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                      <div className="glass px-3 py-2 rounded-lg text-xs">
                        <p className="font-semibold text-foreground">{layer.name}</p>
                        <p className="text-muted-foreground font-mono">{layer.size}</p>
                      </div>
                    </div>
                  </div>
                  <p className="text-xs font-mono text-muted-foreground mt-2 whitespace-nowrap">
                    {layer.name}
                  </p>
                </motion.div>
              );
            })}
          </div>
          
          <div className="mt-8 flex items-center justify-center gap-2 text-sm text-muted-foreground">
            <span className="inline-block w-3 h-3 rounded bg-gradient-to-r from-blue-500 to-rose-500" />
            Data flows left to right through the network
          </div>
        </div>

        {/* Layer legend */}
        <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { type: "Convolutional", desc: "Feature extraction with learnable filters" },
            { type: "Pooling", desc: "Downsampling to reduce spatial dimensions" },
            { type: "Dense", desc: "Fully connected classification layers" },
            { type: "Dropout", desc: "Regularization to prevent overfitting" },
          ].map((item) => (
            <motion.div
              key={item.type}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              className="glass rounded-xl p-4"
            >
              <h4 className="font-semibold text-foreground text-sm mb-1">{item.type}</h4>
              <p className="text-xs text-muted-foreground">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ModelArchitecture;