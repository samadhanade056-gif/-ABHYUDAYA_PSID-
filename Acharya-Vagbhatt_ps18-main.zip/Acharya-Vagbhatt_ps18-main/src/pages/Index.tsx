import HeroSection from "@/components/HeroSection";
import ClassifierSection from "@/components/ClassifierSection";
import PipelineVisualization from "@/components/PipelineVisualization";
import ModelArchitecture from "@/components/ModelArchitecture";
import DatasetGallery from "@/components/DatasetGallery";

const Index = () => {
  return (
    <main className="min-h-screen bg-background">
      <HeroSection />
      <ClassifierSection />
      <PipelineVisualization />
      <ModelArchitecture />
      <DatasetGallery />
      
      {/* Footer */}
      <footer className="py-12 px-4 border-t border-border">
        <div className="container max-w-6xl mx-auto text-center">
          <p className="text-sm text-muted-foreground">
            Built with deep learning principles • CIFAR-10 Dataset • CNN Architecture
          </p>
        </div>
      </footer>
    </main>
  );
};

export default Index;